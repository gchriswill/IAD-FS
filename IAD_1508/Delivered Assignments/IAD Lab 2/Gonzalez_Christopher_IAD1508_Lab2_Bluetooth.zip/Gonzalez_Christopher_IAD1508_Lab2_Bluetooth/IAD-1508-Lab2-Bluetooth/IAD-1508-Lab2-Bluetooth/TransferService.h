
//
//  TransferService.h
//  IAD-1508-Lab2-Bluetooth
//
//  Created by Christopher Gonzalez on 8/7/15.
//  Copyright (c) 2015 Christopher Gonzalez. All rights reserved.
//

#ifndef LE_Transfer_TransferService_h
#define LE_Transfer_TransferService_h

#define TRANSFER_SERVICE_UUID           @"06B280C1-419D-4D87-810E-00D88B506717"
#define TRANSFER_CHARACTERISTIC_UUID    @"CD570797-087C-4008-B692-7835A1246377"

#endif



