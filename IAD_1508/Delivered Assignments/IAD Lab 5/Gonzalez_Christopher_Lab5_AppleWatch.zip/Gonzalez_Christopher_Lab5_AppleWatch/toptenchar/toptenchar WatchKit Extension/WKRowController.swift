//
//  customRowController.swift
//  toptenchar
//
//  Created by Christopher Gonzalez on 8/22/15.
//  Copyright (c) 2015 Christopher Gonzalez. All rights reserved.
//

import WatchKit

class WKRowController: NSObject {
    
    @IBOutlet var rowTitle: WKInterfaceLabel!
    
}
