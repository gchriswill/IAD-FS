//
//  CWKListDelegate.swift
//  toptenchar
//
//  Created by Christopher Gonzalez on 8/17/15.
//  Copyright (c) 2015 Christopher Gonzalez. All rights reserved.
//

import UIKit

class CWKListDelegate: NSObject, UITableViewDelegate {
    

   
}
